/**
 * CogniSurv – TopBar
 * Header with branding, live stats, and the global query bar.
 */
import { useState } from "react";
import { useStore } from "../store/store";
import { queryDashboard } from "../services/api";

const QUICK_CHIPS = [
  "Maternal · Bihar",
  "Anemia · UP",
  "Critical Districts",
  "Kerala Benchmark",
  "Escalating Risk",
  "Telangana",
  "Hyderabad",
];

export default function TopBar() {
  const [queryText, setQueryText] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const { districts, setQueryResult, setQueryLoading, setActiveTab } = useStore();

  const handleInput = (val) => {
    setQueryText(val);
    if (!val.trim()) { setSuggestions([]); return; }
    const matches = districts
      .filter((d) =>
        d.name.toLowerCase().includes(val.toLowerCase()) ||
        d.state.toLowerCase().includes(val.toLowerCase())
      )
      .slice(0, 6)
      .map((d) => ({ label: `${d.name}, ${d.state}`, id: d.id, hint: d.risk_category }));
    setSuggestions(matches);
  };

  const runQuery = async (q) => {
    setQueryText(q);
    setSuggestions([]);
    setQueryLoading(true);
    setActiveTab("query");
    try {
      const result = await queryDashboard(q);
      setQueryResult(result);
    } finally {
      setQueryLoading(false);
    }
  };

  const criticalCount = districts.filter((d) => d.risk_score >= 80).length;

  return (
    <header className="top-bar">
      <div className="top-bar-left">
        <div className="helix-logo">
          <span className="helix-icon">⌬</span>
          <span className="helix-name">Helix</span>
        </div>
        <div className="divider" />
        <div>
          <div className="app-title">CogniSurv — Maternal &amp; Anemia Surveillance</div>
          <div className="app-sub">Cognitive Disease Surveillance Map · India · AI-Powered</div>
        </div>
        <span className="event-badge">MedFusion Hackfest 2026</span>
      </div>

      <div className="query-bar">
        <span className="query-label">🔍 QUERY:</span>
        <div className="query-input-wrap">
          <input
            className="query-input"
            value={queryText}
            onChange={(e) => handleInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && runQuery(queryText)}
            placeholder="Search any disease, region, or indicator — e.g. 'Bihar anemia'…"
          />
          {suggestions.length > 0 && (
            <div className="suggestions">
              {suggestions.map((s) => (
                <div key={s.id} className="suggestion-item" onClick={() => runQuery(s.label)}>
                  <span className="sugg-type">district</span>
                  <span>{s.label}</span>
                  <span className="sugg-hint">{s.hint}</span>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="quick-chips">
          {QUICK_CHIPS.map((c) => (
            <button key={c} className="chip" onClick={() => runQuery(c)}>{c}</button>
          ))}
        </div>
      </div>

      <div className="top-stats">
        <div className="live-dot" />
        <div className="stat"><span className="stat-val red">{criticalCount}</span><span className="stat-lbl">Critical Districts</span></div>
        <div className="stat"><span className="stat-val amber">97</span><span className="stat-lbl">India MMR/100K</span></div>
        <div className="stat"><span className="stat-val pink">57%</span><span className="stat-lbl">Anemia in Women</span></div>
      </div>
    </header>
  );
}
