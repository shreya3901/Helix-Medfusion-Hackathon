/**
 * CogniSurv – Dashboard (main app shell)
 * Wires together all panels and manages data loading.
 */
import { useEffect } from "react";
import { useStore } from "../store/store";
import { useWebSocket } from "../hooks/useWebSocket";
import {
  fetchAllDistricts, fetchGlobalStats,
  fetchIndiaData, fetchAlerts, fetchTimeline, fetchSourceStatus,
} from "../services/api";

import TopBar from "./TopBar";
import ChartPanel from "./ChartPanel";
import DistrictSearch from "./DistrictSearch";
import AlertBanner from "./AlertBanner";
import RssAlertsTab from "./RssAlertsTab";
import DataSourcesPanel from "./DataSourcesPanel";
import NotificationBell from "./NotificationBell";

export default function Dashboard() {
  useWebSocket();

  const {
    setDistricts, setGlobalStats, setIndiaStateData,
    setAlerts, setTimelineEvents, setSourceStatus,
    activeTab, setActiveTab,
  } = useStore();

  useEffect(() => {
    (async () => {
      try {
        const [districts, globalStats, indiaData, alerts, timeline, status] =
          await Promise.all([
            fetchAllDistricts(),
            fetchGlobalStats(),
            fetchIndiaData(),
            fetchAlerts({ limit: 20 }),
            fetchTimeline(20),
            fetchSourceStatus(),
          ]);
        setDistricts(districts);
        setGlobalStats(globalStats);
        setIndiaStateData(indiaData);
        setAlerts(alerts);
        setTimelineEvents(timeline);
        setSourceStatus(status);
      } catch (err) {
        console.error("Initial data load failed:", err);
      }
    })();
  }, []);

  const tabs = [
    { id: "map",      label: "🗺 Risk Map" },
    { id: "query",    label: "🔍 Query Results" },
    { id: "surv",     label: "📊 Surveillance" },
    { id: "timeline", label: "📅 Outbreak Timeline" },
    { id: "trends",   label: "📈 Historical Trends" },
  ];

  return (
    <div className="dashboard">
      <TopBar />

      {/* Global alert banner for critical new alerts */}
      <AlertBanner />

      {/* Nav tabs */}
      <nav className="nav-tabs">
        {tabs.map((t) => (
          <button
            key={t.id}
            className={`nav-tab ${activeTab === t.id ? "active" : ""}`}
            onClick={() => setActiveTab(t.id)}
          >
            {t.label}
          </button>
        ))}
        <div className="nav-spacer" />
        <NotificationBell />
      </nav>

      {/* Tab panels */}
      <main className="main-content">
        {activeTab === "map"      && <MapPanel />}
        {activeTab === "query"    && <QueryPanel />}
        {activeTab === "surv"     && <ChartPanel />}
        {activeTab === "timeline" && <RssAlertsTab />}
        {activeTab === "trends"   && <TrendsPanel />}
      </main>
    </div>
  );
}

// These would be their own files in a production build
function MapPanel() {
  return (
    <div className="map-layout">
      <DistrictSearch />
      <div id="leaflet-map" className="map-container" />
      <DataSourcesPanel />
    </div>
  );
}

function QueryPanel() {
  const { queryResult, queryLoading } = useStore();
  if (queryLoading) return <div className="loading">Searching…</div>;
  if (!queryResult)  return <div className="empty-state">Use the query bar above to search any disease, region, or indicator.</div>;
  return (
    <div className="query-results">
      <h2>Results for: "{queryResult.query}"</h2>
      <p>{queryResult.total} districts matched · Sources: {queryResult.sources_used.join(", ")}</p>
      <table>
        <thead>
          <tr><th>District</th><th>State</th><th>Type</th><th>Risk</th><th>Trend</th><th>Top Driver</th></tr>
        </thead>
        <tbody>
          {queryResult.matched_districts.map((d) => (
            <tr key={d.id}>
              <td>{d.name}</td>
              <td>{d.state}</td>
              <td>{d.type_label}</td>
              <td>{d.risk_score}</td>
              <td>{d.roc_icon} {d.rate_of_change > 0 ? "+" : ""}{d.rate_of_change}/mo</td>
              <td>{d.drivers[0]?.name} ({d.drivers[0]?.val})</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function TrendsPanel() {
  return (
    <div className="trends-panel">
      <ChartPanel mode="trends" />
    </div>
  );
}
