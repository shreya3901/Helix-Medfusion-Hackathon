/**
 * CogniSurv – DistrictSearch
 * Left sidebar: filter pills, search input, ranked district list.
 * Clicking a district fires selectDistrict → map fly-to + AI panel.
 */
import { useStore } from "../store/store";

function getRiskColor(score) {
  if (score >= 80) return "#F87171";
  if (score >= 60) return "#FB923C";
  if (score >= 40) return "#FBBF24";
  return "#34D399";
}

function getRocIcon(roc) {
  if (roc >= 6)  return "▲▲";
  if (roc >= 3)  return "▲";
  if (roc > 0)   return "↗";
  if (roc === 0) return "→";
  return "↓";
}

function getRocColor(roc) {
  if (roc >= 6)  return "#F87171";
  if (roc >= 3)  return "#FB923C";
  if (roc > 0)   return "#FBBF24";
  if (roc === 0) return "#6B8CAE";
  return "#34D399";
}

export default function DistrictSearch() {
  const {
    filteredDistricts,
    selectedDistrictId,
    activeFilter,
    searchQuery,
    setActiveFilter,
    setSearchQuery,
    selectDistrict,
  } = useStore();

  const filters = [
    { id: "all", label: "All" },
    { id: "mat", label: "Maternal" },
    { id: "ane", label: "Anemia" },
  ];

  return (
    <aside className="district-sidebar">
      {/* Filter pills */}
      <div className="sidebar-section">
        <div className="section-label">Focus Layer</div>
        <div className="filter-pills">
          {filters.map((f) => (
            <button
              key={f.id}
              className={`filter-pill ${activeFilter === f.id ? "active-" + f.id : ""}`}
              onClick={() => setActiveFilter(f.id)}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Search */}
      <div className="sidebar-section">
        <input
          className="district-search-input"
          type="text"
          placeholder="Search district / state…"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Count */}
      <div className="district-count">
        {filteredDistricts.length} of 31 districts
      </div>

      {/* District list */}
      <div className="district-list">
        {filteredDistricts.map((d) => {
          const color = getRiskColor(d.risk_score);
          const rocColor = getRocColor(d.rate_of_change);
          const typeColor = d.risk_type === "mat" ? "#F472B6" : "#FBBF24";
          const isActive = selectedDistrictId === d.id;

          return (
            <div
              key={d.id}
              className={`district-item ${isActive ? "active" : ""}`}
              onClick={() => selectDistrict(d.id)}
            >
              <div className="district-row">
                <span className="district-name">{d.name}</span>
                <span className="district-score" style={{ color }}>{d.risk_score}</span>
              </div>
              <div className="district-meta">
                <span className="type-dot" style={{ background: typeColor }} />
                {d.state} · {d.type_label}
              </div>
              <div className="roc-line" style={{ color: rocColor }}>
                {getRocIcon(d.rate_of_change)}{" "}
                {d.rate_of_change > 0 ? "+" : ""}{d.rate_of_change} pts/mo
              </div>
              <div className="risk-bar-wrap">
                <div
                  className="risk-bar"
                  style={{ width: `${d.risk_score}%`, background: color }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </aside>
  );
}
