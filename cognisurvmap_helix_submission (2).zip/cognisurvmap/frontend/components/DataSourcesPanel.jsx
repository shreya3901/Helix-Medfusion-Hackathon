/**
 * CogniSurv – DataSourcesPanel
 * Right-side AI causal analysis panel.
 * Shows risk gauge, drivers, sparkline, rate-of-change badge,
 * plain-English box, and streams the LLM explanation.
 */
import { useEffect, useRef, useState } from "react";
import { useStore } from "../store/store";
import { streamExplanation } from "../services/api";

function getRiskColor(score) {
  if (score >= 80) return "#F87171";
  if (score >= 60) return "#FB923C";
  if (score >= 40) return "#FBBF24";
  return "#34D399";
}

function getRiskLabel(score) {
  if (score >= 80) return "Critical";
  if (score >= 60) return "High Risk";
  if (score >= 40) return "Moderate";
  return "Low Risk";
}

function getRocInfo(roc) {
  if (roc >= 6)  return { label: `Rapidly escalating · +${roc} pts/month`, color: "#F87171", icon: "▲▲", cls: "roc-up" };
  if (roc >= 3)  return { label: `Escalating · +${roc} pts/month`,         color: "#FB923C", icon: "▲",  cls: "roc-up" };
  if (roc > 0)   return { label: `Slowly rising · +${roc} pts/month`,      color: "#FBBF24", icon: "↗",  cls: "roc-stable" };
  if (roc === 0) return { label: "Stable · no change",                      color: "#6B8CAE", icon: "→",  cls: "roc-stable" };
  return { label: `Improving · ${roc} pts/month`, color: "#34D399", icon: "↓", cls: "roc-down" };
}

export default function DataSourcesPanel() {
  const { districts, selectedDistrictId } = useStore();
  const [explanation, setExplanation] = useState("");
  const [streaming, setStreaming] = useState(false);
  const esRef = useRef(null);

  const district = districts.find((d) => d.id === selectedDistrictId);

  useEffect(() => {
    if (!district) return;

    // Close any existing SSE stream
    esRef.current?.close();
    setExplanation("");
    setStreaming(true);

    const es = streamExplanation(district.id, false);
    esRef.current = es;

    es.onmessage = (e) => {
      if (e.data === "[DONE]") {
        setStreaming(false);
        es.close();
        return;
      }
      try {
        const { chunk } = JSON.parse(e.data);
        setExplanation((prev) => prev + chunk);
      } catch (_) {}
    };

    es.onerror = () => {
      // Fallback to static explanation if LLM unavailable
      setExplanation(district.ai_explanation || "AI explanation unavailable.");
      setStreaming(false);
      es.close();
    };

    return () => es.close();
  }, [selectedDistrictId]);

  if (!district) {
    return (
      <aside className="ai-panel">
        <div className="ai-panel-header">
          <span className="ai-icon">✦</span>
          <div>
            <div className="ai-title">AI Causal Analysis</div>
            <div className="ai-subtitle">Maternal & Anemia Risk Interpreter</div>
          </div>
        </div>
        <div className="ai-empty">
          <div className="empty-icon">⬡</div>
          <p>Click any district on the map<br />for AI causal analysis</p>
        </div>
      </aside>
    );
  }

  const color = getRiskColor(district.risk_score);
  const roc   = getRocInfo(district.rate_of_change);
  const typeColor = district.risk_type === "mat" ? "#F472B6" : "#FBBF24";
  const circ  = 2 * Math.PI * 20;
  const dash  = circ * (district.risk_score / 100);

  // Sparkline points
  const trend = district.trend_data || [];
  const sp = trend.map((v, i) => `${16 + i * 28},${68 - v * 0.48}`).join(" ");
  const ap = `M16,68 ${trend.map((v, i) => `L${16 + i * 28},${68 - v * 0.48}`).join(" ")} L${16 + 6 * 28},68 Z`;

  return (
    <aside className="ai-panel">
      {/* Header */}
      <div className="ai-panel-header">
        <span className="ai-icon">✦</span>
        <div>
          <div className="ai-title">AI Causal Analysis</div>
          <div className="ai-subtitle">Maternal &amp; Anemia Risk Interpreter</div>
        </div>
      </div>

      <div className="ai-body">
        {/* District name */}
        <div className="district-big-name">{district.name}</div>
        <div className="district-state-line">
          {district.state} · Primary:{" "}
          <span style={{ color: typeColor }}>{district.type_label}</span>
        </div>

        {/* Rate of change badge */}
        <div className={`roc-badge ${roc.cls}`}>
          <span className="roc-icon">{roc.icon}</span>
          <div className="roc-text">
            <strong style={{ color: roc.color }}>Rate of change</strong>
            <br />{roc.label}
          </div>
          <span className="roc-val" style={{ color: roc.color }}>
            {district.rate_of_change > 0 ? "+" : ""}{district.rate_of_change}/mo
          </span>
        </div>

        {/* Plain English box */}
        <div className="plain-box">
          <div className="plain-label">💡 What does this mean?</div>
          <div
            className="plain-text"
            dangerouslySetInnerHTML={{ __html: district.plain_english }}
          />
        </div>

        {/* Gauge card */}
        <div className="gauge-card">
          <div className="gauge-wrap">
            <svg width="50" height="50" viewBox="0 0 50 50" style={{ transform: "rotate(-90deg)" }}>
              <circle cx="25" cy="25" r="20" fill="none" stroke="rgba(255,255,255,.05)" strokeWidth="4" />
              <circle
                cx="25" cy="25" r="20" fill="none"
                stroke={color} strokeWidth="4"
                strokeDasharray={`${dash.toFixed(1)} ${circ.toFixed(1)}`}
                strokeLinecap="round"
              />
            </svg>
            <div className="gauge-num" style={{ color }}>{district.risk_score}</div>
          </div>
          <div>
            <div className="gauge-label">Composite Risk Score</div>
            <div className="gauge-cat" style={{ color }}>{getRiskLabel(district.risk_score)}</div>
            <div className="gauge-meta">RF Model v2.1 · Updated 2h ago</div>
          </div>
        </div>

        {/* Drivers */}
        <div className="sec-label">Key Risk Drivers</div>
        {district.drivers.map((dr) => (
          <div key={dr.name} className="driver-row">
            <span className="driver-dot" style={{ background: dr.color }} />
            <span className="driver-name">{dr.name}</span>
            <span className="driver-val">{dr.val}</span>
            <div className="driver-bar-wrap">
              <div className="driver-bar" style={{ width: `${dr.pct}%`, background: dr.color }} />
            </div>
          </div>
        ))}

        {/* Sparkline */}
        <div className="sec-label">7-Month Risk Trend</div>
        <div className="spark-card">
          <svg width="100%" viewBox="0 0 220 72">
            <defs>
              <linearGradient id={`sg-${district.id}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity=".3" />
                <stop offset="100%" stopColor={color} stopOpacity="0" />
              </linearGradient>
            </defs>
            <path d={ap} fill={`url(#sg-${district.id})`} />
            <polyline points={sp} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            {trend.map((v, i) => (
              <circle
                key={i}
                cx={16 + i * 28} cy={68 - v * 0.48} r="2.5"
                fill={color} opacity={i === 6 ? 1 : 0.35}
              />
            ))}
          </svg>
        </div>

        {/* AI explanation */}
        <div className="ai-card">
          <div className="ai-card-label">
            <span style={{ color: "#F472B6" }}>✦</span> GenAI Causal Interpretation
          </div>
          <div className="ai-card-text">
            {explanation}
            {streaming && <span className="typing-cursor" />}
          </div>
        </div>
      </div>
    </aside>
  );
}
