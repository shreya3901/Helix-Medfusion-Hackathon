/**
 * CogniSurv – RssAlertsTab
 * Renders the Outbreak Timeline tab with events from all 6 sources.
 * Sources: ProMED · WHO GHO · HealthMap · CDC · ECDC · NFHS-5
 */
import { useStore } from "../store/store";

const SOURCE_TAGS = {
  "ProMED":   { bg: "rgba(251,191,36,.1)",  border: "rgba(251,191,36,.3)",  color: "#FDE68A" },
  "WHO GHO":  { bg: "rgba(56,189,248,.1)",  border: "rgba(56,189,248,.3)",  color: "#7DD3FC" },
  "HealthMap":{ bg: "rgba(129,140,248,.1)", border: "rgba(129,140,248,.3)", color: "#C4B5FD" },
  "CDC":      { bg: "rgba(52,211,153,.1)",  border: "rgba(52,211,153,.3)",  color: "#6EE7B7" },
  "ECDC":     { bg: "rgba(248,113,113,.1)", border: "rgba(248,113,113,.3)", color: "#FCA5A5" },
  "NFHS-5":   { bg: "rgba(244,114,182,.1)", border: "rgba(244,114,182,.3)", color: "#FBCFE8" },
};

const SEV_COLOR = {
  critical: "#F87171",
  high:     "#FB923C",
  moderate: "#FBBF24",
  low:      "#34D399",
};

function SourceTag({ source }) {
  const style = SOURCE_TAGS[source] || SOURCE_TAGS["ProMED"];
  return (
    <span
      className="source-tag"
      style={{ background: style.bg, border: `1px solid ${style.border}`, color: style.color }}
    >
      {source}
    </span>
  );
}

export default function RssAlertsTab() {
  const { timelineEvents } = useStore();

  const legend = [
    { label: "Critical",  color: "#F87171" },
    { label: "High",      color: "#FB923C" },
    { label: "Moderate",  color: "#FBBF24" },
    { label: "Low / Positive", color: "#34D399" },
  ];

  return (
    <div className="timeline-panel">
      <div className="timeline-header">
        <h2>Maternal &amp; Anemia Outbreak Timeline 2025–2026</h2>
        <div className="source-tags-row">
          {Object.keys(SOURCE_TAGS).map((s) => <SourceTag key={s} source={s} />)}
        </div>
        <div className="legend-row">
          {legend.map((l) => (
            <span key={l.label} className="legend-item">
              <span className="legend-dot" style={{ background: l.color }} />
              {l.label}
            </span>
          ))}
        </div>
      </div>

      <div className="timeline">
        <div className="timeline-line" />
        {timelineEvents.map((event, idx) => (
          <div key={idx} className="timeline-item">
            <div
              className="timeline-dot"
              style={{ background: SEV_COLOR[event.severity] || "#6B8CAE" }}
            />
            <div className="timeline-content">
              <div className="timeline-meta">
                <span className="timeline-date">{event.date}</span>
                <SourceTag source={event.src} />
                <span
                  className="sev-badge"
                  style={{ color: SEV_COLOR[event.severity] }}
                >
                  {event.severity?.toUpperCase()}
                </span>
              </div>
              <div className="timeline-title">{event.title}</div>
              <div className="timeline-desc">{event.desc}</div>
              {event.url && (
                <a className="timeline-link" href={event.url} target="_blank" rel="noreferrer">
                  View source →
                </a>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
