/**
 * CogniSurv – NotificationBell
 * Bell icon in the nav bar showing unread alert count.
 * Click to switch to the Outbreak Timeline tab.
 */
import { useStore } from "../store/store";

export default function NotificationBell() {
  const { unreadAlertCount, markAlertsRead, setActiveTab } = useStore();

  const handleClick = () => {
    markAlertsRead();
    setActiveTab("timeline");
  };

  return (
    <button className="notification-bell" onClick={handleClick} title="View outbreak alerts">
      🔔
      {unreadAlertCount > 0 && (
        <span className="bell-badge">{unreadAlertCount > 9 ? "9+" : unreadAlertCount}</span>
      )}
    </button>
  );
}
