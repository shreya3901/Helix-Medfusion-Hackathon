/**
 * CogniSurv – ChartPanel
 * Renders Chart.js visualisations for the Surveillance and Trends tabs.
 */
import { useEffect, useRef } from "react";
import { Chart, registerables } from "chart.js";
import { useStore } from "../store/store";

Chart.register(...registerables);

const CHART_DEFAULTS = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: { legend: { labels: { color: "#6B8CAE", font: { size: 9 } } } },
  scales: {
    x: { ticks: { color: "#6B8CAE", font: { size: 9 } }, grid: { color: "rgba(30,58,95,.4)" } },
    y: { ticks: { color: "#6B8CAE", font: { size: 9 } }, grid: { color: "rgba(30,58,95,.4)" } },
  },
};

function useChart(ref, config) {
  useEffect(() => {
    if (!ref.current) return;
    const chart = new Chart(ref.current, config);
    return () => chart.destroy();
  }, []);
}

export default function ChartPanel({ mode = "surveillance" }) {
  const { globalStats, indiaStateData, districts } = useStore();

  const riskRef  = useRef();
  const radarRef = useRef();
  const corrRef  = useRef();
  const mmrRef   = useRef();
  const anemiaRef = useRef();
  const instRef  = useRef();
  const anc4Ref  = useRef();

  // ── Risk doughnut ──────────────────────────────────────────
  useChart(riskRef, {
    type: "doughnut",
    data: {
      labels: ["Critical (80+)", "High (60–79)", "Moderate (40–59)", "Low (<40)"],
      datasets: [{
        data: [
          districts.filter((d) => d.risk_score >= 80).length,
          districts.filter((d) => d.risk_score >= 60 && d.risk_score < 80).length,
          districts.filter((d) => d.risk_score >= 40 && d.risk_score < 60).length,
          districts.filter((d) => d.risk_score  < 40).length,
        ],
        backgroundColor: ["rgba(248,113,113,.7)","rgba(251,146,60,.7)","rgba(251,191,36,.7)","rgba(52,211,153,.7)"],
        borderColor:      ["#F87171","#FB923C","#FBBF24","#34D399"],
        borderWidth: 1,
      }],
    },
    options: { ...CHART_DEFAULTS },
  });

  // ── Anemia drivers radar ───────────────────────────────────
  useChart(radarRef, {
    type: "radar",
    data: {
      labels: ["Iron Deficiency","Low ANC","Home Delivery","Adolescent Anemia","Poor Sanitation","Sickle Cell"],
      datasets: [{
        label: "Burden Score",
        data: [87, 72, 65, 71, 68, 38],
        backgroundColor: "rgba(244,114,182,.15)",
        borderColor: "#F472B6",
        borderWidth: 1.5,
        pointBackgroundColor: "#F472B6",
        pointRadius: 3,
      }],
    },
    options: {
      ...CHART_DEFAULTS,
      scales: { r: { ticks: { display: false }, grid: { color: "rgba(30,58,95,.7)" }, pointLabels: { color: "#6B8CAE", font: { size: 9 } } } },
    },
  });

  // ── MMR vs Anemia scatter ──────────────────────────────────
  useChart(corrRef, {
    type: "scatter",
    data: {
      datasets: [{
        label: "States",
        data: [
          { x: 63, y: 218, label: "Bihar" },
          { x: 59, y: 167, label: "UP" },
          { x: 61, y: 215, label: "Assam" },
          { x: 54, y: 163, label: "MP" },
          { x: 47, y: 57,  label: "Telangana" },
          { x: 46, y: 141, label: "Rajasthan" },
          { x: 45, y: 38,  label: "Maharashtra" },
          { x: 44, y: 69,  label: "Karnataka" },
          { x: 41, y: 34,  label: "Hyderabad" },
          { x: 31, y: 19,  label: "Kerala" },
        ],
        backgroundColor: "rgba(244,114,182,.65)",
        borderColor: "#F472B6",
        pointRadius: 8,
        pointHoverRadius: 10,
      }],
    },
    options: {
      ...CHART_DEFAULTS,
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: (ctx) => `${ctx.raw.label} — Anemia: ${ctx.raw.x}%, MMR: ${ctx.raw.y}` } },
      },
      scales: {
        x: { ...CHART_DEFAULTS.scales.x, title: { display: true, text: "Anemia Prevalence (%)", color: "#6B8CAE", font: { size: 10 } } },
        y: { ...CHART_DEFAULTS.scales.y, title: { display: true, text: "MMR per 100K",          color: "#6B8CAE", font: { size: 10 } } },
      },
    },
  });

  const years = ["2015","2016","2017","2018","2019","2020","2021","2022","2023","2024","2025"];

  // ── MMR trend ─────────────────────────────────────────────
  useChart(mmrRef, {
    type: "line",
    data: {
      labels: years,
      datasets: [
        { label:"Bihar",     data:[340,320,310,290,270,258,245,232,225,221,218], borderColor:"#F87171",  backgroundColor:"transparent", borderWidth:2, tension:.4, pointRadius:2 },
        { label:"Assam",     data:[328,310,295,275,260,248,238,228,220,217,215], borderColor:"#FB923C",  backgroundColor:"transparent", borderWidth:2, tension:.4, pointRadius:2 },
        { label:"UP",        data:[285,268,252,238,220,206,195,183,174,170,167], borderColor:"#FBBF24",  backgroundColor:"transparent", borderWidth:2, tension:.4, pointRadius:2 },
        { label:"Telangana", data:[118,105, 92, 80, 70, 65, 62, 60, 58, 57, 57], borderColor:"#818CF8", backgroundColor:"transparent", borderWidth:2, tension:.4, pointRadius:2 },
        { label:"Karnataka", data:[144,133,122,111,102, 94, 85, 78, 73, 71, 69], borderColor:"#38BDF8", backgroundColor:"transparent", borderWidth:1.5,tension:.4, pointRadius:2 },
        { label:"Kerala",    data:[ 61, 52, 46, 39, 34, 29, 26, 23, 21, 20, 19], borderColor:"#34D399", backgroundColor:"transparent", borderWidth:2, tension:.4, pointRadius:2 },
      ],
    },
    options: { ...CHART_DEFAULTS, scales: { ...CHART_DEFAULTS.scales, y: { ...CHART_DEFAULTS.scales.y, title: { display:true, text:"MMR per 100,000", color:"#6B8CAE", font:{size:9} } } } },
  });

  // ── Anemia trend ──────────────────────────────────────────
  useChart(anemiaRef, {
    type: "line",
    data: {
      labels: years,
      datasets: [
        { label:"Bihar",    data:[68,67,66,66,65,64,64,63,63,63,63], borderColor:"#F87171", backgroundColor:"rgba(248,113,113,.05)", borderWidth:2, fill:true, tension:.4, pointRadius:2 },
        { label:"National", data:[53,53,52,52,52,51,51,57,57,57,57], borderColor:"#818CF8", backgroundColor:"transparent", borderWidth:2, borderDash:[5,3], tension:.4, pointRadius:2 },
        { label:"Telangana",data:[54,52,51,50,49,48,47,47,47,47,47], borderColor:"#F472B6", backgroundColor:"transparent", borderWidth:1.5, tension:.4, pointRadius:2 },
        { label:"Kerala",   data:[40,38,37,36,35,33,32,31,31,31,31], borderColor:"#34D399", backgroundColor:"transparent", borderWidth:1.5, tension:.4, pointRadius:2 },
      ],
    },
    options: { ...CHART_DEFAULTS, scales: { ...CHART_DEFAULTS.scales, y: { ...CHART_DEFAULTS.scales.y, title: { display:true, text:"Anemia prevalence (%)", color:"#6B8CAE", font:{size:9} } } } },
  });

  if (mode === "trends") {
    return (
      <div className="charts-grid">
        <div className="chart-card"><h3>MMR Trend 2015–2025</h3><div className="chart-h"><canvas ref={mmrRef}/></div></div>
        <div className="chart-card"><h3>Anemia Prevalence 2015–2025</h3><div className="chart-h"><canvas ref={anemiaRef}/></div></div>
      </div>
    );
  }

  return (
    <div className="charts-grid">
      <div className="chart-card"><h3>District Risk Distribution</h3><div className="chart-h-sm"><canvas ref={riskRef}/></div></div>
      <div className="chart-card"><h3>Anemia Driver Breakdown</h3><div className="chart-h-sm"><canvas ref={radarRef}/></div></div>
      <div className="chart-card full-width"><h3>MMR vs Anemia Correlation (State-level)</h3><div className="chart-h"><canvas ref={corrRef}/></div></div>
    </div>
  );
}
