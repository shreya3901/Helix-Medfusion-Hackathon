/**
 * CogniSurv – AlertBanner
 * Shows a dismissible banner at the top when a new critical alert arrives.
 */
import { useState, useEffect } from "react";
import { useStore } from "../store/store";

export default function AlertBanner() {
  const { alerts } = useStore();
  const [visible, setVisible] = useState(false);
  const [currentAlert, setCurrentAlert] = useState(null);

  useEffect(() => {
    const critical = alerts.find((a) => a.severity === "critical");
    if (critical && critical !== currentAlert) {
      setCurrentAlert(critical);
      setVisible(true);
      // Auto-dismiss after 8 seconds
      const t = setTimeout(() => setVisible(false), 8000);
      return () => clearTimeout(t);
    }
  }, [alerts]);

  if (!visible || !currentAlert) return null;

  return (
    <div className="alert-banner critical">
      <span className="alert-banner-dot" />
      <div className="alert-banner-content">
        <strong>{currentAlert.source}</strong>: {currentAlert.title}
      </div>
      <button className="alert-banner-dismiss" onClick={() => setVisible(false)}>✕</button>
    </div>
  );
}
