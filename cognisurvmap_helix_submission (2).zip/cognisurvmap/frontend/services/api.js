/**
 * CogniSurv – API Service
 * All HTTP calls to the FastAPI backend.
 */

const BASE = import.meta.env.VITE_API_URL || "http://localhost:8000/api";

async function get(path) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) throw new Error(`API error ${res.status}: ${path}`);
  return res.json();
}

async function post(path, body) {
  const res = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`API error ${res.status}: ${path}`);
  return res.json();
}

// ── Districts ────────────────────────────────────────────────

export const fetchAllDistricts = (filters = {}) => {
  const params = new URLSearchParams(filters).toString();
  return get(`/districts${params ? "?" + params : ""}`);
};

export const fetchDistrict = (id) => get(`/districts/${id}`);

/**
 * Stream LLM explanation via SSE.
 * Returns an EventSource that emits { chunk } events.
 */
export const streamExplanation = (districtId, plain = false) => {
  const url = `${BASE}/districts/${districtId}/explain?plain=${plain}`;
  return new EventSource(url);
};

// ── Surveillance ─────────────────────────────────────────────

export const fetchGlobalStats = () => get("/surveillance/global");

export const fetchIndiaData = () => get("/surveillance/india");

export const fetchTrends = (indicator = "mmr", region = "all") =>
  get(`/surveillance/trends?indicator=${indicator}&region=${region}`);

// ── Alerts ───────────────────────────────────────────────────

export const fetchAlerts = (params = {}) => {
  const qs = new URLSearchParams(params).toString();
  return get(`/alerts${qs ? "?" + qs : ""}`);
};

export const refreshAlerts = () => post("/alerts/refresh", {});

// ── Query ────────────────────────────────────────────────────

export const queryDashboard = (query) => post("/query", { query });

// ── Timeline ─────────────────────────────────────────────────

export const fetchTimeline = (limit = 20) => get(`/timeline?limit=${limit}`);

// ── Sources ──────────────────────────────────────────────────

export const fetchSourceStatus = () => get("/sources/status");
