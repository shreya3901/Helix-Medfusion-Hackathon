/**
 * CogniSurv – Global State Store (Zustand)
 */
import { create } from "zustand";

export const useStore = create((set, get) => ({
  // ── Districts ──────────────────────────────────────────────
  districts: [],
  selectedDistrictId: null,
  activeFilter: "all",         // "all" | "mat" | "ane"
  searchQuery: "",

  setDistricts: (districts) => set({ districts }),

  selectDistrict: (id) => set({ selectedDistrictId: id }),

  setActiveFilter: (filter) => set({ activeFilter: filter }),

  setSearchQuery: (q) => set({ searchQuery: q }),

  updateDistrictRisk: (id, score) =>
    set((state) => ({
      districts: state.districts.map((d) =>
        d.id === id ? { ...d, risk_score: score } : d
      ),
    })),

  get filteredDistricts() {
    const { districts, activeFilter, searchQuery } = get();
    return districts
      .filter((d) => activeFilter === "all" || d.risk_type === activeFilter)
      .filter(
        (d) =>
          !searchQuery ||
          d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          d.state.toLowerCase().includes(searchQuery.toLowerCase())
      )
      .sort((a, b) => b.risk_score - a.risk_score);
  },

  // ── Alerts ────────────────────────────────────────────────
  alerts: [],
  unreadAlertCount: 0,

  setAlerts: (alerts) =>
    set({ alerts, unreadAlertCount: alerts.filter((a) => !a.read).length }),

  addAlert: (alert) =>
    set((state) => ({
      alerts: [alert, ...state.alerts].slice(0, 100),
      unreadAlertCount: state.unreadAlertCount + 1,
    })),

  markAlertsRead: () => set({ unreadAlertCount: 0 }),

  // ── Global stats ──────────────────────────────────────────
  globalStats: null,
  setGlobalStats: (stats) => set({ globalStats: stats }),

  // ── India surveillance ────────────────────────────────────
  indiaStateData: [],
  setIndiaStateData: (data) => set({ indiaStateData: data }),

  // ── Timeline ──────────────────────────────────────────────
  timelineEvents: [],
  setTimelineEvents: (events) => set({ timelineEvents: events }),

  // ── Query results ─────────────────────────────────────────
  queryResult: null,
  queryLoading: false,
  setQueryResult: (result) => set({ queryResult: result }),
  setQueryLoading: (loading) => set({ queryLoading: loading }),

  // ── Active tab ─────────────────────────────────────────────
  activeTab: "map",
  setActiveTab: (tab) => set({ activeTab: tab }),

  // ── Source status ─────────────────────────────────────────
  sourceStatus: {},
  setSourceStatus: (status) => set({ sourceStatus: status }),
}));
