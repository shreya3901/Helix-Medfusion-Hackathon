# CogniSurv — Maternal Mortality & Anemia Surveillance
### Team Helix · MedFusion Hackfest 2026 · Mahindra University, Hyderabad

---

## Run the backend in 3 steps (Windows / Mac / Linux)

### Step 1 — Install dependencies

```bash
cd cognisurvmap/backend
python -m venv venv
```

**Windows:**
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
venv\Scripts\activate
pip install -r requirements.txt
```

**Mac / Linux:**
```bash
source venv/bin/activate
pip install -r requirements.txt
```

### Step 2 — Add your API key

```bash
cp .env.example .env
```

Open `.env` and add your Anthropic API key:
```
ANTHROPIC_API_KEY=your_key_here
```

> The key is only needed for the AI causal explanation endpoint.
> All other endpoints (Disease.sh, WHO, ProMED, alerts, districts) work without any key.

### Step 3 — Start the server

```bash
uvicorn app.main:app --reload --port 8000
```

You will see:
```
INFO: Starting CogniSurv backend...
INFO: ETL refresh started...
INFO: httpx HTTP Request: GET https://disease.sh/v3/covid-19/all "HTTP/1.1 200 OK"
INFO: httpx HTTP Request: GET https://ghoapi.azureedge.net/api/... "HTTP/1.1 200 OK"
INFO: Application startup complete.
```

---

## View the live API

Open your browser and go to:
```
http://localhost:8000/docs
```

This shows all endpoints with live "Try it out" buttons.

---

## Run the frontend

**Option A — just double-click:**
Open `cognisurvmap_helix.html` directly in Chrome. No setup needed.

**Option B — via terminal (second terminal window):**
```bash
cd cognisurvmap
python -m http.server 3000
```
Then open: `http://localhost:3000/cognisurvmap_helix.html`

---

## Key endpoints to test

| Endpoint | What it shows |
|---|---|
| `GET /api/surveillance/global` | Live data from Disease.sh |
| `GET /api/alerts` | ProMED + WHO + CDC + HealthMap alerts |
| `GET /api/districts/purnea` | District risk score + drivers |
| `GET /api/districts/hyderabad` | Hyderabad district data |
| `POST /api/query` body: `{"query":"Bihar anemia"}` | Unified query interface |
| `GET /api/surveillance/india` | NFHS-5 state level data |
| `GET /api/timeline` | Outbreak timeline events |
| `GET /api/sources/status` | Data source health check |
| `GET /localhost:8000/api/districts/purnea/explain` | Claude API streaming live |

---

## Data sources integrated (7 required)

| Source | Method | Status |
|---|---|---|
| Disease.sh | REST API | Live on startup |
| WHO GHO | OData API | Live on startup |
| ProMED Mail | RSS Feed | Live on startup |
| CDC Open Data | API + RSS | Live on startup |
| HealthMap | Scraping | Live on startup |
| ECDC | API | Live on startup |
| IHME / NFHS-5 | CSV / District data | Loaded from data/districts.py |

---

## Project structure

```
cognisurvmap/
├── cognisurvmap_helix.html     ← standalone frontend (open in Chrome)
├── backend/
│   ├── requirements.txt
│   ├── .env.example
│   └── app/
│       ├── main.py             ← FastAPI entry point
│       ├── config.py           ← settings
│       ├── api/routes.py       ← all endpoints
│       ├── data/districts.py   ← 31 districts across 13 states
│       ├── models/             ← Pydantic schemas
│       └── services/
│           ├── etl_service.py  ← fetches all 7 data sources
│           ├── alert_service.py← ProMED, WHO, CDC, HealthMap, ECDC
│           ├── llm_service.py  ← Claude API streaming
│           ├── risk_model.py   ← Random Forest risk scoring
│           └── ws_manager.py   ← WebSocket live updates
└── frontend/
    ├── components/             ← React components
    ├── services/api.js         ← API calls
    ├── hooks/useWebSocket.js   ← live updates
    └── store/store.js          ← Zustand state
```

---

## 31 districts · 13 states
Telangana (Hyderabad, Mahabubnagar, Adilabad, Nizamabad, Warangal) · Bihar · UP · Jharkhand · MP · Maharashtra · Rajasthan · Karnataka · Kerala · AP · West Bengal · Assam · Gujarat
