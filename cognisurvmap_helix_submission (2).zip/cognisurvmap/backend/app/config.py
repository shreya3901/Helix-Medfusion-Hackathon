from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # Anthropic
    ANTHROPIC_API_KEY: str = ""
    LLM_MODEL: str = "claude-sonnet-4-20250514"
    LLM_MAX_TOKENS: int = 1024

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://postgres:password@localhost:5432/cognisurvmap"

    # Redis
    REDIS_URL: str = "redis://localhost:6379"
    CACHE_TTL_SECONDS: int = 300

    # Disease.sh — no auth needed
    DISEASE_SH_BASE: str = "https://disease.sh/v3"

    # WHO GHO
    WHO_GHO_BASE: str = "https://ghoapi.azureedge.net/api"

    # CDC
    CDC_API_BASE: str = "https://data.cdc.gov/resource"
    CDC_APP_TOKEN: Optional[str] = None

    # HealthMap
    HEALTHMAP_BASE: str = "https://healthmap.org"

    # ProMED RSS
    PROMED_RSS: str = "https://promedmail.org/feed/"

    # ECDC
    ECDC_BASE: str = "https://opendata.ecdc.europa.eu"

    # CDC FluView RSS
    CDC_FLUVIEW_RSS: str = "https://tools.cdc.gov/api/v2/resources/media/404952.rss"

    # ETL
    ETL_REFRESH_MINUTES: int = 5
    DEBUG: bool = False

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
