import asyncio
import httpx
import feedparser
import logging
from datetime import datetime
from typing import List, Dict, Optional, Any
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from app.config import settings
from app.data.districts import DISTRICT_DATA

logger = logging.getLogger(__name__)

_cache: Dict[str, Any] = {}
_source_status: Dict[str, Dict] = {}


def _set_cache(key: str, value: Any):
    _cache[key] = {"value": value, "ts": datetime.utcnow().isoformat()}


def _get_cache(key: str) -> Optional[Any]:
    return _cache.get(key, {}).get("value")


class ETLService:

    def __init__(self):
        self.client = httpx.AsyncClient(timeout=15.0)
        self.scheduler = AsyncIOScheduler()

    async def start_scheduler(self):
        self.scheduler.add_job(
            self._refresh_all,
            "interval",
            minutes=settings.ETL_REFRESH_MINUTES,
            id="etl_refresh",
        )
        self.scheduler.start()
        await self._refresh_all()

    async def stop_scheduler(self):
        self.scheduler.shutdown(wait=False)
        await self.client.aclose()

    async def _refresh_all(self):
        logger.info("ETL refresh started...")
        tasks = [
            self._fetch_disease_sh(),
            self._fetch_who_gho(),
            self._fetch_nfhs5_data(),
        ]
        await asyncio.gather(*tasks, return_exceptions=True)
        logger.info("ETL refresh complete.")

    async def _fetch_disease_sh(self):
        try:
            resp = await self.client.get(f"{settings.DISEASE_SH_BASE}/covid-19/all")
            resp.raise_for_status()
            _set_cache("global_stats", resp.json())
            _source_status["disease.sh"] = {"status": "ok", "last_fetch": datetime.utcnow().isoformat()}
        except Exception as e:
            logger.error(f"disease.sh fetch failed: {e}")
            _source_status["disease.sh"] = {"status": "error", "error": str(e)}

    async def _fetch_who_gho(self):
        indicators = ["MDG_0000000026", "WHOSIS_000008"]
        results = []
        for indicator in indicators:
            try:
                url = f"{settings.WHO_GHO_BASE}/{indicator}?$filter=SpatialDim eq 'IND'&$top=20"
                resp = await self.client.get(url)
                resp.raise_for_status()
                for item in resp.json().get("value", []):
                    results.append({
                        "indicator": indicator,
                        "region": item.get("SpatialDim", "India"),
                        "year": item.get("TimeDim", 2024),
                        "value": item.get("NumericValue"),
                        "source": "WHO GHO",
                    })
            except Exception as e:
                logger.error(f"WHO GHO fetch failed for {indicator}: {e}")
        if results:
            _set_cache("who_gho_data", results)
        _source_status["WHO GHO"] = {
            "status": "ok" if results else "error",
            "last_fetch": datetime.utcnow().isoformat()
        }

    async def _fetch_nfhs5_data(self):
        nfhs5 = [
            {"state": "Bihar",          "mmr": 218, "anemia_prevalence": 63.0, "inst_delivery_rate": 76.0,  "anc4_coverage": 17.0, "year": 2021, "source": "NFHS-5"},
            {"state": "Uttar Pradesh",  "mmr": 167, "anemia_prevalence": 59.0, "inst_delivery_rate": 83.0,  "anc4_coverage": 21.0, "year": 2021, "source": "NFHS-5"},
            {"state": "Assam",          "mmr": 215, "anemia_prevalence": 61.0, "inst_delivery_rate": 84.0,  "anc4_coverage": 28.0, "year": 2021, "source": "NFHS-5"},
            {"state": "Madhya Pradesh", "mmr": 163, "anemia_prevalence": 54.0, "inst_delivery_rate": 94.0,  "anc4_coverage": 23.0, "year": 2021, "source": "NFHS-5"},
            {"state": "Rajasthan",      "mmr": 141, "anemia_prevalence": 46.0, "inst_delivery_rate": 92.0,  "anc4_coverage": 30.0, "year": 2021, "source": "NFHS-5"},
            {"state": "Maharashtra",    "mmr": 38,  "anemia_prevalence": 45.0, "inst_delivery_rate": 97.0,  "anc4_coverage": 58.0, "year": 2021, "source": "NFHS-5"},
            {"state": "Karnataka",      "mmr": 69,  "anemia_prevalence": 44.0, "inst_delivery_rate": 97.0,  "anc4_coverage": 68.0, "year": 2021, "source": "NFHS-5"},
            {"state": "Kerala",         "mmr": 19,  "anemia_prevalence": 31.0, "inst_delivery_rate": 99.9,  "anc4_coverage": 97.0, "year": 2021, "source": "NFHS-5"},
            {"state": "Telangana",      "mmr": 57,  "anemia_prevalence": 47.0, "inst_delivery_rate": 95.0,  "anc4_coverage": 65.0, "year": 2021, "source": "NFHS-5"},
            {"state": "Andhra Pradesh", "mmr": 45,  "anemia_prevalence": 46.0, "inst_delivery_rate": 94.0,  "anc4_coverage": 60.0, "year": 2021, "source": "NFHS-5"},
            {"state": "West Bengal",    "mmr": 98,  "anemia_prevalence": 53.0, "inst_delivery_rate": 90.0,  "anc4_coverage": 44.0, "year": 2021, "source": "NFHS-5"},
            {"state": "Gujarat",        "mmr": 57,  "anemia_prevalence": 54.0, "inst_delivery_rate": 95.0,  "anc4_coverage": 57.0, "year": 2021, "source": "NFHS-5"},
            {"state": "Jharkhand",      "mmr": 71,  "anemia_prevalence": 65.0, "inst_delivery_rate": 76.0,  "anc4_coverage": 22.0, "year": 2021, "source": "NFHS-5"},
        ]
        _set_cache("nfhs5_state_data", nfhs5)

    async def fetch_global_stats(self) -> Dict:
        cached = _get_cache("global_stats")
        if not cached:
            await self._fetch_disease_sh()
            cached = _get_cache("global_stats") or {}
        return {
            "source": "disease.sh",
            "cases":        cached.get("cases", 0),
            "deaths":       cached.get("deaths", 0),
            "recovered":    cached.get("recovered", 0),
            "active":       cached.get("active", 0),
            "today_cases":  cached.get("todayCases", 0),
            "today_deaths": cached.get("todayDeaths", 0),
            "fetched_at":   _cache.get("global_stats", {}).get("ts", datetime.utcnow().isoformat()),
        }

    async def get_all_districts(self) -> List[Dict]:
        return DISTRICT_DATA

    async def get_district_by_id(self, district_id: str) -> Optional[Dict]:
        for d in DISTRICT_DATA:
            if d["id"] == district_id:
                return d
        return None

    async def get_india_state_data(self) -> List[Dict]:
        if not _get_cache("nfhs5_state_data"):
            await self._fetch_nfhs5_data()
        return _get_cache("nfhs5_state_data") or []

    async def get_historical_trends(self, indicator: str, region: str) -> Dict:
        years = list(range(2015, 2026))
        trends = {
            "mmr": {
                "Bihar":     [340,320,310,290,270,258,245,232,225,221,218],
                "Assam":     [328,310,295,275,260,248,238,228,220,217,215],
                "UP":        [285,268,252,238,220,206,195,183,174,170,167],
                "MP":        [260,244,228,214,200,188,178,170,165,164,163],
                "Karnataka": [144,133,122,111,102, 94, 85, 78, 73, 71, 69],
                "Telangana": [118,105, 92, 80, 70, 65, 62, 60, 58, 57, 57],
                "Kerala":    [ 61, 52, 46, 39, 34, 29, 26, 23, 21, 20, 19],
            },
            "anemia": {
                "Bihar":     [68,67,66,66,65,64,64,63,63,63,63],
                "UP":        [62,62,61,61,60,60,59,59,59,59,59],
                "Assam":     [66,65,64,63,62,62,61,61,61,61,61],
                "National":  [53,53,52,52,52,51,51,57,57,57,57],
                "Telangana": [54,52,51,50,49,48,47,47,47,47,47],
                "Kerala":    [40,38,37,36,35,33,32,31,31,31,31],
            },
        }
        data = trends.get(indicator, {})
        if region != "all" and region in data:
            return {"years": years, "indicator": indicator, "series": {region: data[region]}}
        return {"years": years, "indicator": indicator, "series": data}

    async def get_source_status(self) -> Dict:
        return _source_status
