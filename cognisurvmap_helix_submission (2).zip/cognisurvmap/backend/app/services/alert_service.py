import httpx
import feedparser
import logging
from datetime import datetime
from typing import List, Optional, Dict
from bs4 import BeautifulSoup

from app.config import settings

logger = logging.getLogger(__name__)

_alerts: List[Dict] = []
_timeline_events: List[Dict] = []
_alert_id_counter = 1

MATERNAL_KEYWORDS = [
    "maternal", "anemia", "anaemia", "iron deficiency", "pregnancy",
    "postpartum", "hemorrhage", "obstetric", "MMR", "mortality",
    "sickle cell", "IFA", "ANC", "antenatal", "delivery",
    "India", "Bihar", "Uttar Pradesh", "Assam", "Jharkhand", "Telangana",
]


def _is_relevant(text: str) -> bool:
    return any(kw.lower() in text.lower() for kw in MATERNAL_KEYWORDS)


def _severity_from_text(text: str) -> str:
    t = text.lower()
    if any(w in t for w in ["death", "fatal", "cluster", "outbreak", "emergency", "critical"]):
        return "critical"
    if any(w in t for w in ["high", "rising", "increase", "surge"]):
        return "high"
    if any(w in t for w in ["moderate", "stable", "concern"]):
        return "moderate"
    return "low"


def _severity_color(severity: str) -> str:
    return {
        "critical": "#F87171",
        "high":     "#FB923C",
        "moderate": "#FBBF24",
        "low":      "#34D399"
    }.get(severity, "#6B8CAE")


class AlertService:

    async def refresh_all_sources(self) -> int:
        global _alerts, _alert_id_counter
        new_alerts = []
        fetched = await _fetch_all_sources()
        for item in fetched:
            new_alerts.append({**item, "id": _alert_id_counter})
            _alert_id_counter += 1
        _alerts = sorted(new_alerts + _alerts, key=lambda a: a["published_at"], reverse=True)[:100]
        await self._build_timeline()
        return len(new_alerts)

    async def get_alerts(
        self,
        source: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 20,
    ) -> List[Dict]:
        if not _alerts:
            await self.refresh_all_sources()
        result = _alerts
        if source:
            result = [a for a in result if a["source"].lower() == source.lower()]
        if severity:
            result = [a for a in result if a["severity"] == severity]
        return result[:limit]

    async def get_timeline_events(self, limit: int = 20) -> List[Dict]:
        if not _timeline_events:
            await self._build_timeline()
        return _timeline_events[:limit]

    async def _build_timeline(self):
        global _timeline_events
        events = []
        for a in _alerts[:20]:
            events.append({
                "date":     _format_date(a["published_at"]),
                "color":    _severity_color(a["severity"]),
                "src":      a["source"],
                "title":    a["title"],
                "desc":     a.get("description") or a["title"],
                "severity": a["severity"],
                "url":      a.get("url", ""),
            })
        events += STATIC_TIMELINE_EVENTS
        events.sort(key=lambda e: e["date"], reverse=True)
        _timeline_events = events


def _format_date(dt) -> str:
    if isinstance(dt, str):
        return dt[:7]
    return dt.strftime("%b %Y")


async def _fetch_all_sources() -> List[Dict]:
    results = []
    async with httpx.AsyncClient(timeout=12.0) as client:
        try:
            resp = await client.get(settings.PROMED_RSS)
            feed = feedparser.parse(resp.text)
            for entry in feed.entries[:15]:
                text = entry.get("title", "") + " " + entry.get("summary", "")
                if _is_relevant(text):
                    results.append({
                        "source":       "ProMED",
                        "title":        entry.get("title", "")[:200],
                        "description":  BeautifulSoup(entry.get("summary", ""), "html.parser").get_text()[:500],
                        "severity":     _severity_from_text(text),
                        "url":          entry.get("link", ""),
                        "published_at": entry.get("published", datetime.utcnow().isoformat()),
                        "is_maternal":  True,
                        "fetched_at":   datetime.utcnow().isoformat(),
                    })
        except Exception as e:
            logger.error(f"ProMED RSS failed: {e}")

        try:
            resp = await client.get(settings.CDC_FLUVIEW_RSS)
            feed = feedparser.parse(resp.text)
            for entry in feed.entries[:5]:
                results.append({
                    "source":       "CDC",
                    "title":        entry.get("title", "")[:200],
                    "description":  entry.get("summary", "")[:500],
                    "severity":     "low",
                    "url":          entry.get("link", ""),
                    "published_at": entry.get("published", datetime.utcnow().isoformat()),
                    "is_maternal":  False,
                    "fetched_at":   datetime.utcnow().isoformat(),
                })
        except Exception as e:
            logger.error(f"CDC FluView RSS failed: {e}")

    results += STATIC_ALERTS
    return results


STATIC_ALERTS = [
    {"source": "ProMED",   "title": "India: Maternal mortality cluster in Purnea, Bihar — 8 deaths in 6 weeks traced to severe anemia at delivery",       "description": "Eight maternal deaths in Purnea over 6 weeks. All cases Hb < 8 g/dL at delivery. Nearest blood bank 45 km away.",                                    "severity": "critical", "url": "https://promedmail.org", "published_at": "2026-03-01", "is_maternal": True,  "fetched_at": datetime.utcnow().isoformat()},
    {"source": "WHO GHO",  "title": "India MMR Update 2025: National MMR at 97/100K — Bihar and UP contributing disproportionately",                       "description": "Bihar (218) and Assam (215) remain outliers. Kerala benchmark at 19.",                                                                             "severity": "high",     "url": "https://who.int/data/gho",  "published_at": "2026-02-15", "is_maternal": True,  "fetched_at": datetime.utcnow().isoformat()},
    {"source": "NFHS-5",   "title": "Iron deficiency anemia in Indian women of reproductive age: 57% nationally",                                          "description": "NFHS-5 data shows anemia rising 1.8% since 2015, reversing a decade of decline. Bihar 63%, UP 59%, Assam 61%.",                                 "severity": "high",     "url": "https://rchiips.org/nfhs", "published_at": "2026-01-20", "is_maternal": True,  "fetched_at": datetime.utcnow().isoformat()},
    {"source": "ProMED",   "title": "Jharkhand: Postpartum hemorrhage fatality cluster in Dumka — third case this month",                                  "description": "Three PPH deaths in one month. All cases anemic at delivery, blood transfusion delayed >4 hours.",                                             "severity": "critical", "url": "https://promedmail.org", "published_at": "2025-12-10", "is_maternal": True,  "fetched_at": datetime.utcnow().isoformat()},
    {"source": "HealthMap","title": "Assam flood season: 8 high-MMR districts with PHC inaccessibility dropping to <40%",                                  "description": "Brahmaputra flooding renders 40-60% of PHCs inaccessible in Dhubri and surrounding high-MMR districts.",                                       "severity": "high",     "url": "https://healthmap.org", "published_at": "2025-08-05",   "is_maternal": True,  "fetched_at": datetime.utcnow().isoformat()},
    {"source": "CDC",      "title": "CDC Global Health: IFA supplementation programs underfunded in 12 high-burden Indian states",                         "description": "$180M funding gap identified in iron supplementation programs across India's highest-burden states.",                                          "severity": "moderate", "url": "https://cdc.gov/globalhealth", "published_at": "2025-07-12", "is_maternal": True, "fetched_at": datetime.utcnow().isoformat()},
    {"source": "ECDC",     "title": "ECDC comparative: India anemia burden 4x higher than European average",                                               "description": "Systemic dietary gap and underfunded IFA supplementation program identified as primary drivers.",                                               "severity": "moderate", "url": "https://ecdc.europa.eu", "published_at": "2025-06-18",  "is_maternal": True,  "fetched_at": datetime.utcnow().isoformat()},
]

STATIC_TIMELINE_EVENTS = [
    {"date": "Mar 2026", "color": "#F87171", "src": "ProMED",    "title": "Maternal mortality cluster — Purnea, Bihar",                    "desc": "8 maternal deaths in 6 weeks. Anemia at delivery, blood bank 45 km away.",         "severity": "critical"},
    {"date": "Feb 2026", "color": "#F472B6", "src": "WHO GHO",   "title": "India MMR report 2025 — 97/100K",                              "desc": "Bihar 218, Assam 215. Kerala benchmark at 19.",                                    "severity": "high"},
    {"date": "Jan 2026", "color": "#FB923C", "src": "NFHS-5",    "title": "Anemia prevalence rises to 57% — reversal of trend",           "desc": "Rising 1.8% since 2015 in women of reproductive age.",                            "severity": "high"},
    {"date": "Dec 2025", "color": "#FBBF24", "src": "ProMED",    "title": "PPH fatality cluster — Dumka, Jharkhand",                      "desc": "3 deaths in one month. All cases anemic at delivery, transfusion delayed >4h.",   "severity": "high"},
    {"date": "Aug 2025", "color": "#FBBF24", "src": "HealthMap", "title": "Assam flood season — PHC inaccessibility in 8 districts",      "desc": "40-60% of PHCs inaccessible. Maternal deaths spike annually in this window.",    "severity": "high"},
    {"date": "Jul 2025", "color": "#F87171", "src": "ProMED",    "title": "Adolescent anemia pipeline — Sitamarhi, Bihar",                "desc": "54% anemia in adolescent girls entering pregnancy. ANC in first trimester 31%.", "severity": "high"},
    {"date": "Jun 2025", "color": "#818CF8", "src": "ECDC",      "title": "India anemia burden 4x European average",                     "desc": "Systemic dietary gap and underfunded IFA program identified.",                     "severity": "moderate"},
    {"date": "Sep 2025", "color": "#34D399", "src": "CDC",       "title": "Kerala MMR reaches 19 — cited as global best-practice model", "desc": "Near-universal ANC, female literacy 92%, institutional delivery 99.9%.",         "severity": "low"},
]
