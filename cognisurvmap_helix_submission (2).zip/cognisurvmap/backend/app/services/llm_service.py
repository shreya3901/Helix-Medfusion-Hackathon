import anthropic
import logging
from typing import AsyncGenerator, Dict

from app.config import settings

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = (
    "You are an epidemiologist specialising in maternal mortality and anemia in India. "
    "Explain why a district's health risk score is at its current level based on the indicators provided. "
    "Be specific, cite the exact numbers, and explain the causal chain in 3-4 sentences. "
    "Do not use bullet points."
)

PLAIN_SYSTEM_PROMPT = (
    "Explain a health risk score to a non-medical audience in simple language. "
    "Avoid jargon. Explain what the risk means for real people living in that district. "
    "Keep it to 2-3 sentences."
)


def _build_prompt(district: Dict, plain_english: bool = False) -> str:
    drivers = district.get("drivers", [])
    driver_text = ", ".join([f"{d['name']} at {d['val']}" for d in drivers])
    roc = district.get("rate_of_change", 0)
    direction = "rising" if roc > 0 else ("falling" if roc < 0 else "stable")

    if plain_english:
        return (
            f"District: {district['name']}, {district['state']}\n"
            f"Risk Score: {district['risk_score']}/100 ({direction})\n"
            f"Main problems: {driver_text}\n\n"
            f"Explain this simply. What does it mean for the women and children living there? "
            f"What is the single most important thing that needs to change?"
        )
    return (
        f"District: {district['name']}, {district['state']}\n"
        f"Focus: {'Maternal Mortality' if district.get('risk_type') == 'mat' else 'Anemia'}\n"
        f"Risk Score: {district['risk_score']}/100 (trend: {direction}, {abs(roc)} pts/month)\n"
        f"Key indicators: {driver_text}\n\n"
        f"Explain the causal chain driving this district's risk score."
    )


class LLMService:

    def __init__(self):
        self.client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)

    async def stream_explanation(
        self, district: Dict, plain_english: bool = False
    ) -> AsyncGenerator[str, None]:
        try:
            prompt = _build_prompt(district, plain_english)
            system = PLAIN_SYSTEM_PROMPT if plain_english else SYSTEM_PROMPT

            async with self.client.messages.stream(
                model=settings.LLM_MODEL,
                max_tokens=settings.LLM_MAX_TOKENS,
                system=system,
                messages=[{"role": "user", "content": prompt}],
            ) as stream:
                async for text in stream.text_stream:
                    yield text

        except anthropic.AuthenticationError:
            logger.error("Invalid Anthropic API key.")
            yield district.get("ai_explanation", "AI explanation unavailable — check API key in .env")
        except Exception as e:
            logger.error(f"LLM stream error: {e}")
            yield district.get("ai_explanation", "AI explanation temporarily unavailable.")

    async def generate_explanation(self, district: Dict, plain_english: bool = False) -> str:
        chunks = []
        async for chunk in self.stream_explanation(district, plain_english):
            chunks.append(chunk)
        return "".join(chunks)
