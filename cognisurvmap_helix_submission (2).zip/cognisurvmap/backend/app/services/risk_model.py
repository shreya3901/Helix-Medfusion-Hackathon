import numpy as np
from typing import Dict, List

FEATURE_WEIGHTS = {
    "anemia_prevalence":       0.28,
    "inst_delivery_rate":      0.18,
    "emoc_distance_km":        0.16,
    "anc4_coverage":           0.12,
    "skilled_birth_attendant": 0.10,
    "female_literacy":         0.08,
    "ifa_supplementation":     0.05,
    "asha_density":            0.03,
}

HIGH_IS_BAD = {"anemia_prevalence", "emoc_distance_km"}

FEATURE_RANGES = {
    "anemia_prevalence":       [0, 100],
    "inst_delivery_rate":      [0, 100],
    "emoc_distance_km":        [0, 100],
    "anc4_coverage":           [0, 100],
    "skilled_birth_attendant": [0, 100],
    "female_literacy":         [0, 100],
    "ifa_supplementation":     [0, 100],
    "asha_density":            [0, 5],
}


class RiskModel:
    """
    Weighted approximation of the trained Random Forest model.
    In production, load the pickled model:
        import joblib
        self.model = joblib.load("models/rf_maternal_risk_v2.pkl")
    """

    def predict(self, features: Dict) -> float:
        score = 0.0
        for feature, weight in FEATURE_WEIGHTS.items():
            value = features.get(feature)
            if value is None:
                continue
            lo, hi = FEATURE_RANGES[feature]
            normalised = (value - lo) / max(hi - lo, 1)
            if feature not in HIGH_IS_BAD:
                normalised = 1 - normalised
            score += normalised * weight * 100
        return round(min(max(score, 0), 100), 1)

    def predict_batch(self, districts: List[Dict]) -> List[float]:
        return [self.predict(d) for d in districts]

    def feature_importance(self) -> Dict:
        return FEATURE_WEIGHTS

    def rate_of_change(self, trend: List[float]) -> float:
        if len(trend) < 2:
            return 0.0
        x = np.arange(len(trend), dtype=float)
        y = np.array(trend, dtype=float)
        return round(float(np.polyfit(x, y, 1)[0]), 1)
