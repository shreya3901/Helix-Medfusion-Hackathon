from sqlalchemy import Column, String, Float, Integer, DateTime, Text, Boolean, JSON
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()


class District(Base):
    __tablename__ = "districts"

    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    state = Column(String, nullable=False)
    lat = Column(Float, nullable=False)
    lng = Column(Float, nullable=False)
    risk_score = Column(Float, default=0)
    risk_type = Column(String, default="mat")
    rate_of_change = Column(Float, default=0)
    trend_data = Column(JSON, default=list)
    drivers = Column(JSON, default=list)
    icd_codes = Column(JSON, default=list)
    ai_explanation = Column(Text, default="")
    last_updated = Column(DateTime, default=datetime.utcnow)


class Alert(Base):
    __tablename__ = "alerts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    source = Column(String, nullable=False)
    title = Column(String, nullable=False)
    description = Column(Text, default="")
    severity = Column(String, default="moderate")
    url = Column(String, default="")
    published_at = Column(DateTime, default=datetime.utcnow)
    fetched_at = Column(DateTime, default=datetime.utcnow)
    is_maternal = Column(Boolean, default=True)


class SurveillanceSnapshot(Base):
    __tablename__ = "surveillance_snapshots"

    id = Column(Integer, primary_key=True, autoincrement=True)
    source = Column(String, nullable=False)
    indicator = Column(String, nullable=False)
    region = Column(String, nullable=False)
    value = Column(Float)
    year = Column(Integer)
    fetched_at = Column(DateTime, default=datetime.utcnow)
