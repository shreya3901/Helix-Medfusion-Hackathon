from pydantic import BaseModel
from typing import List, Optional, Any
from datetime import datetime


class DriverSchema(BaseModel):
    name: str
    val: str
    pct: float
    color: str


class DistrictSummary(BaseModel):
    id: str
    name: str
    state: str
    lat: float
    lng: float
    risk_score: float
    risk_type: str
    rate_of_change: float
    trend_data: List[float]
    drivers: List[DriverSchema]
    icd_codes: List[str]
    risk_category: str
    type_label: str


class DistrictDetail(DistrictSummary):
    ai_explanation: str
    plain_english: str
    roc_label: str
    roc_icon: str
    last_updated: Optional[datetime] = None


class AlertSchema(BaseModel):
    id: int
    source: str
    title: str
    description: str
    severity: str
    url: str
    published_at: Any
    is_maternal: bool


class StateIndicator(BaseModel):
    state: str
    mmr: Optional[float]
    anemia_prevalence: Optional[float]
    inst_delivery_rate: Optional[float]
    anc4_coverage: Optional[float]
    year: int
    source: str


class GlobalStatsSchema(BaseModel):
    source: str
    cases: float
    deaths: float
    recovered: float
    active: float
    today_cases: float
    today_deaths: float
    fetched_at: Any


class QueryRequest(BaseModel):
    query: str


class QueryResult(BaseModel):
    query: str
    matched_districts: List[DistrictSummary]
    total: int
    sources_used: List[str]


class ExplainRequest(BaseModel):
    district_id: str
    plain_english: bool = False
