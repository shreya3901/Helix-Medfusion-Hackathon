from app.models.schemas import (
    DistrictSummary, DistrictDetail,
    AlertSchema, StateIndicator,
    GlobalStatsSchema, QueryResult
)
