from app.data.districts import DISTRICT_DATA
