from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import logging

from app.api.routes import router
from app.services.etl_service import ETLService
from app.config import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting CogniSurv backend...")
    etl = ETLService()
    await etl.start_scheduler()
    yield
    await etl.stop_scheduler()


app = FastAPI(
    title="CogniSurv API",
    description="Maternal Mortality & Anemia Surveillance — Team Helix, MedFusion 2026",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix="/api")


@app.get("/health")
async def health():
    return JSONResponse({
        "status": "ok",
        "team": "Helix",
        "event": "MedFusion Hackfest 2026"
    })
