from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse
from typing import List, Optional
import json

from app.models.schemas import (
    DistrictSummary, DistrictDetail, AlertSchema,
    StateIndicator, GlobalStatsSchema, QueryResult, QueryRequest
)
from app.services.etl_service import ETLService
from app.services.alert_service import AlertService
from app.services.llm_service import LLMService
from app.services.risk_model import RiskModel

router = APIRouter()
etl = ETLService()
alert_svc = AlertService()
llm_svc = LLMService()
risk_model = RiskModel()


@router.get("/districts", response_model=List[DistrictSummary])
async def get_all_districts(
    state: Optional[str] = None,
    risk_type: Optional[str] = None,
    min_risk: Optional[float] = None,
):
    districts = await etl.get_all_districts()
    if state:
        districts = [d for d in districts if d["state"].lower() == state.lower()]
    if risk_type:
        districts = [d for d in districts if d["risk_type"] == risk_type]
    if min_risk is not None:
        districts = [d for d in districts if d["risk_score"] >= min_risk]
    return sorted(districts, key=lambda d: d["risk_score"], reverse=True)


@router.get("/districts/{district_id}", response_model=DistrictDetail)
async def get_district(district_id: str):
    district = await etl.get_district_by_id(district_id)
    if not district:
        raise HTTPException(status_code=404, detail=f"District '{district_id}' not found")
    return district


@router.get("/districts/{district_id}/explain")
async def explain_district(district_id: str, plain: bool = False):
    district = await etl.get_district_by_id(district_id)
    if not district:
        raise HTTPException(status_code=404, detail=f"District '{district_id}' not found")

    async def event_stream():
        async for chunk in llm_svc.stream_explanation(district, plain_english=plain):
            yield f"data: {json.dumps({'chunk': chunk})}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.get("/surveillance/global", response_model=GlobalStatsSchema)
async def get_global_stats():
    return await etl.fetch_global_stats()


@router.get("/surveillance/india", response_model=List[StateIndicator])
async def get_india_surveillance():
    return await etl.get_india_state_data()


@router.get("/surveillance/trends")
async def get_trends(indicator: str = "mmr", region: str = "all"):
    return await etl.get_historical_trends(indicator=indicator, region=region)


@router.get("/alerts", response_model=List[AlertSchema])
async def get_alerts(
    source: Optional[str] = None,
    severity: Optional[str] = None,
    limit: int = Query(default=20, le=100),
):
    return await alert_svc.get_alerts(source=source, severity=severity, limit=limit)


@router.post("/alerts/refresh")
async def refresh_alerts():
    count = await alert_svc.refresh_all_sources()
    return {"refreshed": count, "sources": ["ProMED", "WHO", "HealthMap", "CDC", "ECDC"]}


@router.post("/query", response_model=QueryResult)
async def unified_query(body: QueryRequest):
    q = body.query.lower().strip()
    all_districts = await etl.get_all_districts()

    if "critical" in q or "urgent" in q:
        results = [d for d in all_districts if d["risk_score"] >= 80]
    elif "escalat" in q:
        results = [d for d in all_districts if d["rate_of_change"] >= 6]
    elif "anemia" in q or " ane" in q:
        results = [d for d in all_districts if d["risk_type"] == "ane"]
    elif "maternal" in q or " mat" in q:
        results = [d for d in all_districts if d["risk_type"] == "mat"]
    elif "kerala" in q or "benchmark" in q:
        results = [d for d in all_districts if d["risk_score"] < 30]
    elif "telangana" in q:
        results = [d for d in all_districts if d["state"] == "Telangana"]
    elif "hyderabad" in q:
        results = [d for d in all_districts if d["id"] == "hyderabad"]
    else:
        results = [
            d for d in all_districts
            if q in d["name"].lower() or q in d["state"].lower()
        ]
        if not results:
            results = sorted(all_districts, key=lambda d: d["risk_score"], reverse=True)[:8]

    return QueryResult(
        query=body.query,
        matched_districts=sorted(results, key=lambda d: d["risk_score"], reverse=True),
        total=len(results),
        sources_used=["NFHS-5", "WHO GHO", "RF Risk Model"],
    )


@router.get("/timeline")
async def get_outbreak_timeline(limit: int = Query(default=20, le=50)):
    return await alert_svc.get_timeline_events(limit=limit)


@router.post("/risk/score")
async def calculate_risk_score(features: dict):
    score = risk_model.predict(features)
    return {"risk_score": score, "model": "RandomForest v2.1"}


@router.get("/sources/status")
async def get_source_status():
    return await etl.get_source_status()
